Credentials user guide
https://github.com/jenkinsci/credentials-plugin/blob/master/docs/user.adoc


https://www.cyberark.com/threat-research-blog/configuring-and-securing-credentials-in-jenkins/

Using user's credentials in pipelines:
https://docwhat.org/jenkins-user-credentials
