# Useful SSH commands


```
# get the fingerprint
ssh-keygen -lf /etc/ssh/ssh_host_ecdsa_key.pub

# get the with MD5
ssh-keygen -E md5 -lf /etc/ssh/ssh_host_ecdsa_key.pub

# get public keys from the host

```


